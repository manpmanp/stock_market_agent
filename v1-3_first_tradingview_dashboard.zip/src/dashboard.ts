// Server-rendered shell + client-side fetch. Served same-origin from this
// Worker (GET /dashboard), so it can call /rankings directly with plain
// fetch() -- no CORS/CSP workarounds needed, unlike an externally-hosted
// page would require.
export function renderDashboard(): string {
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Stock Watchlist</title>
<style>
  :root {
    color-scheme: light;
    --surface-1:      #fcfcfb;
    --page:           #f9f9f7;
    --text-primary:   #0b0b0b;
    --text-secondary: #52514e;
    --text-muted:     #898781;
    --gridline:       #e1e0d9;
    --border:         rgba(11,11,11,0.10);
    --good:           #2a9d4a;
    --bad:            #d9772a;
    --growth:         #2a78d6;
    --seq-400:        #3987e5;
  }
  @media (prefers-color-scheme: dark) {
    :root:not([data-theme="light"]) {
      color-scheme: dark;
      --surface-1:      #1a1a19;
      --page:           #0d0d0d;
      --text-primary:   #ffffff;
      --text-secondary: #c3c2b7;
      --text-muted:     #898781;
      --gridline:       #2c2c2a;
      --border:         rgba(255,255,255,0.10);
      --good:           #37b85c;
      --bad:            #e08a3f;
      --growth:         #3987e5;
      --seq-400:        #3987e5;
    }
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    background: var(--page);
    color: var(--text-primary);
    font: 15px/1.5 system-ui, -apple-system, "Segoe UI", sans-serif;
    padding: 24px 16px 64px;
  }
  h1 { font-size: 20px; margin: 0 0 4px; }
  .sub { color: var(--text-secondary); font-size: 13px; margin: 0 0 20px; max-width: 560px; }
  main { max-width: 1100px; margin: 0 auto; }
  section { margin-bottom: 40px; }
  h2 { font-size: 15px; margin: 0 0 12px; }
  .tabs { display: flex; gap: 6px; margin-bottom: 16px; }
  .tab {
    font-size: 13px; padding: 6px 12px; border-radius: 999px; border: 1px solid var(--border);
    background: var(--surface-1); color: var(--text-secondary); cursor: pointer;
  }
  .tab[aria-selected="true"] { color: var(--text-primary); border-color: var(--seq-400); font-weight: 600; }
  .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; }
  @media (max-width: 700px) { .grid { grid-template-columns: 1fr; } }
  .card {
    background: var(--surface-1); border: 1px solid var(--border); border-radius: 10px;
    padding: 14px;
  }
  .card .top-row { display: flex; align-items: center; gap: 6px; margin-bottom: 6px; }
  .card .ticker-text { font-size: 16px; font-weight: 600; }
  .card .badges-row { margin-bottom: 8px; }
  .card .score-row { display: flex; align-items: baseline; gap: 6px; margin-bottom: 8px; }
  .card .score { font-size: 22px; font-weight: 700; font-variant-numeric: tabular-nums; }
  .card .score-label { font-size: 11px; color: var(--text-muted); }
  .bar-track { height: 6px; border-radius: 3px; background: var(--gridline); overflow: hidden; margin-bottom: 6px; }
  .bar-fill { height: 100%; border-radius: 3px; background: var(--seq-400); }
  .card .rationale { font-size: 12px; color: var(--text-secondary); margin-top: 8px; }
  .badge {
    display: inline-block; font-size: 11px; font-weight: 600; padding: 2px 8px;
    border-radius: 999px; color: #fff; margin-right: 4px;
  }
  .badge.growth { background: var(--growth); }
  .badge.defensive { background: var(--bad); }
  .badge.blend { background: var(--text-muted); }
  .badge.undervalued, .badge.pullback_in_uptrend { background: var(--good); }
  .badge.overvalued, .badge.downtrend { background: var(--bad); }
  .badge.fair_value, .badge.neutral, .badge.near_historical_highs { background: var(--text-muted); }
  .empty { color: var(--text-muted); font-size: 13px; padding: 12px; }
  .stat-row { display: flex; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
  .stat {
    background: var(--surface-1); border: 1px solid var(--border); border-radius: 10px;
    padding: 12px 16px; min-width: 120px;
  }
  .stat .v { font-size: 22px; font-weight: 700; font-variant-numeric: tabular-nums; }
  .stat .l { font-size: 11px; color: var(--text-muted); }
  .tv-range-row { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 10px; }
  .tv-range-btn {
    font-size: 11px; font-weight: 600; padding: 3px 9px; border-radius: 999px;
    border: 1px solid var(--border); background: var(--surface-1); color: var(--text-secondary);
    cursor: pointer; font: inherit; font-size: 11px;
  }
  .tv-range-btn.active { color: #fff; background: var(--seq-400); border-color: var(--seq-400); }
  .tv-widget-container { height: 420px; margin-top: 6px; border-radius: 8px; overflow: hidden; }
  .tv-empty { color: var(--text-muted); font-size: 12px; padding: 44px 0; text-align: center; }
  .tv-credit { font-size: 10px; color: var(--text-muted); margin-top: 4px; }
</style>
</head>
<body>
<main>
  <h1>Stock Watchlist</h1>
  <p class="sub" id="disclaimer">Loading...</p>
  <div class="stat-row" id="stats"></div>

  <section>
    <h2>Candidates by horizon</h2>
    <div class="tabs" role="tablist">
      <button class="tab" data-horizon="short" role="tab">Short-term</button>
      <button class="tab" data-horizon="mid" role="tab">Mid-term</button>
      <button class="tab" data-horizon="long" role="tab" aria-selected="true">Long-term</button>
    </div>
    <div class="grid" id="cardGrid"></div>
  </section>
</main>

<script>
let currentHorizon = "long";
let cache = {};

// Maps this project's Yahoo Finance ticker spelling to TradingView's symbol
// format (EXCHANGE:SYMBOL), used only to embed TradingView's own official
// chart widget below. Hand-mapped from known conventions, one entry per
// universe ticker -- add an entry here whenever a ticker is added to
// config/universe.json.
const TV_SYMBOL_MAP = {
  "VOLV-B.ST": "OMXSTO:VOLV_B",
  "ERIC-B.ST": "OMXSTO:ERIC_B",
  "HM-B.ST": "OMXSTO:HM_B",
  "ATCO-A.ST": "OMXSTO:ATCO_A",
  "INVE-B.ST": "OMXSTO:INVE_B",
  "SAND.ST": "OMXSTO:SAND",
  "SEB-A.ST": "OMXSTO:SEB_A",
  "SWED-A.ST": "OMXSTO:SWED_A",
  "TELIA.ST": "OMXSTO:TELIA",
  "EVO.ST": "OMXSTO:EVO",
  "AAPL": "NASDAQ:AAPL",
  "MSFT": "NASDAQ:MSFT",
  "GOOGL": "NASDAQ:GOOGL",
  "AMZN": "NASDAQ:AMZN",
  "NVDA": "NASDAQ:NVDA",
  "META": "NASDAQ:META",
  "BRK-B": "NYSE:BRK.B",
  "JNJ": "NYSE:JNJ",
  "JPM": "NYSE:JPM",
  "XOM": "NYSE:XOM",
};

// Preset date-range buttons rendered above each TradingView widget, mapped
// onto the widget's own documented "range" config parameter.
const RANGE_OPTIONS = [
  { label: '1D', range: '1D' },
  { label: '1W', range: '5D' },
  { label: '1M', range: '1M' },
  { label: '3M', range: '3M' },
  { label: '6M', range: '6M' },
  { label: '1Y', range: '12M' },
  { label: '5Y', range: '60M' },
  { label: 'All', range: 'ALL' },
];
const DEFAULT_RANGE = '12M';
let selectedRanges = {};

async function fetchHorizon(h) {
  if (cache[h]) return cache[h];
  const resp = await fetch('/rankings?horizon=' + h);
  const data = await resp.json();
  cache[h] = data;
  return data;
}

function styleBadge(style) {
  if (!style) return '';
  const label = style.charAt(0).toUpperCase() + style.slice(1);
  return '<span class="badge ' + style + '">' + label + '</span>';
}

const LABEL_TEXT = {
  undervalued: 'Undervalued (own history)', overvalued: 'Overvalued (own history)', fair_value: 'Fair value',
  pullback_in_uptrend: 'Pullback in uptrend', downtrend: 'Downtrend', near_historical_highs: 'Near own highs', neutral: 'No strong signal',
};

function verdictBadges(r) {
  const parts = [];
  if (r.valuation_label) parts.push('<span class="badge ' + r.valuation_label + '">' + (LABEL_TEXT[r.valuation_label] || r.valuation_label) + '</span>');
  if (r.entry_state) parts.push('<span class="badge ' + r.entry_state + '">' + (LABEL_TEXT[r.entry_state] || r.entry_state) + '</span>');
  return parts.join('');
}

function cssSafe(ticker) { return ticker.replace(/[^a-zA-Z0-9]/g, '_'); }

function chartBlockHtml(ticker) {
  const id = cssSafe(ticker);
  const activeRange = selectedRanges[ticker] || DEFAULT_RANGE;
  const rangeRow = '<div class="tv-range-row" data-ticker="' + ticker + '">' +
    RANGE_OPTIONS.map(o =>
      '<button class="tv-range-btn' + (o.range === activeRange ? ' active' : '') + '" data-ticker="' + ticker + '" data-range="' + o.range + '">' + o.label + '</button>'
    ).join('') +
  '</div>';
  return rangeRow +
    '<div class="tv-widget-container" id="tvwrap-' + id + '"><div class="tv-empty">Loading chart...</div></div>' +
    '<div class="tv-credit">Chart by TradingView</div>';
}

// Loads (or re-loads) the TradingView Advanced Chart widget for one ticker
// into its container. TradingView's widget live-updates on its own once
// embedded.
function loadChart(ticker) {
  const id = cssSafe(ticker);
  const wrap = document.getElementById('tvwrap-' + id);
  if (!wrap) return;
  const symbol = TV_SYMBOL_MAP[ticker];
  if (!symbol) {
    wrap.innerHTML = '<div class="tv-empty">No TradingView symbol mapped for ' + ticker + ' yet.</div>';
    return;
  }
  wrap.innerHTML = '';
  // TradingView's autosize:true widget measures its container's box on
  // creation. If we build the script tag synchronously, the browser hasn't
  // run a layout pass yet and the container can still measure 0x0, so the
  // widget mounts with no data. A double requestAnimationFrame defers this
  // past the next two paints.
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      const liveWrap = document.getElementById('tvwrap-' + id);
      if (!liveWrap) return;
      const container = document.createElement('div');
      container.className = 'tradingview-widget-container';
      container.style.height = '100%';
      container.style.width = '100%';
      const widgetDiv = document.createElement('div');
      widgetDiv.className = 'tradingview-widget-container__widget';
      container.appendChild(widgetDiv);
      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.src = 'https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js';
      script.async = true;
      const theme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
      script.text = JSON.stringify({
        autosize: true,
        symbol: symbol,
        interval: 'D',
        range: selectedRanges[ticker] || DEFAULT_RANGE,
        timezone: 'Etc/UTC',
        theme: theme,
        style: '1',
        locale: 'en',
        allow_symbol_change: false,
        support_host: 'https://www.tradingview.com',
      });
      container.appendChild(script);
      liveWrap.innerHTML = '';
      liveWrap.appendChild(container);
    });
  });
}

function renderCardGrid(rankings) {
  const rows = rankings.slice().sort((a, b) => a.rank - b.rank);
  const grid = document.getElementById('cardGrid');
  if (rows.length === 0) {
    grid.innerHTML = '<div class="empty">No rankings yet -- run /ingest then /score.</div>';
    return;
  }
  grid.innerHTML = rows.map(r => {
    const pct = Math.max(0, Math.min(100, r.composite_score));
    const gapLabel = r.valuation_gap_pct == null ? '' :
      (r.valuation_gap_pct < 0 ? 'below' : 'above') + ' fair value by ' +
      Math.abs(Math.round(r.valuation_gap_pct * 1000) / 10) + '%';
    return '<div class="card">' +
      '<div class="top-row"><span class="ticker-text">' + r.ticker + '</span>' + styleBadge(r.style) + '</div>' +
      '<div class="badges-row">' + verdictBadges(r) + '</div>' +
      '<div class="score-row"><span class="score">' + r.composite_score + '</span><span class="score-label">/ 100 fit for this horizon</span></div>' +
      '<div class="bar-track"><div class="bar-fill" style="width:' + pct + '%"></div></div>' +
      '<div class="rationale">' + (gapLabel ? gapLabel + '. ' : '') + (r.rationale || '') + '</div>' +
      chartBlockHtml(r.ticker) +
    '</div>';
  }).join('');
}

function loadAllCharts(rankings) {
  rankings.forEach(r => loadChart(r.ticker));
}

function renderStats(data) {
  const el = document.getElementById('stats');
  const runAt = data.rankings[0] ? data.rankings[0].run_at : null;
  el.innerHTML =
    '<div class="stat"><div class="v">' + data.rankings.length + '</div><div class="l">Scored</div></div>' +
    '<div class="stat"><div class="v">' + data.excluded.length + '</div><div class="l">Excluded</div></div>' +
    '<div class="stat"><div class="v" style="font-size:14px">' + (runAt || '\\u2014') + '</div><div class="l">Last run (UTC)</div></div>';
  document.getElementById('disclaimer').textContent = data.disclaimer;
}

document.addEventListener('click', (e) => {
  const rangeBtn = e.target.closest ? e.target.closest('.tv-range-btn') : null;
  if (!rangeBtn) return;
  const ticker = rangeBtn.dataset.ticker;
  const range = rangeBtn.dataset.range;
  if (selectedRanges[ticker] === range) return;
  selectedRanges[ticker] = range;
  const row = rangeBtn.closest('.tv-range-row');
  if (row) row.querySelectorAll('.tv-range-btn').forEach(b => b.classList.toggle('active', b.dataset.range === range));
  loadChart(ticker);
});

async function render() {
  const data = await fetchHorizon(currentHorizon);
  renderStats(data);
  renderCardGrid(data.rankings);
  loadAllCharts(data.rankings);
}

document.querySelectorAll('.tab').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(b => b.setAttribute('aria-selected', 'false'));
    btn.setAttribute('aria-selected', 'true');
    currentHorizon = btn.dataset.horizon;
    render();
  });
});

render();
</script>
</body>
</html>`;
}
